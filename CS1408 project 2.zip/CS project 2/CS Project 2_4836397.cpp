/* Andrew Baker
CS Project Number 2
University Bookstore Receipt Output File Program
Last Date Modified: 9/28/2017 at 1:08pm */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <cstdlib>

using namespace std;
int main()
{
   int Size;
   cout << "Please enter the number of customers that are being checked out." <<endl;
   cin>> Size;
    // While confirmation loop
    while (Size >10 || Size <5)
    {
         cout << "Please enter the number of customers that are being checked out.  Please enter between 5 and 10." <<endl;
        cin>> Size;
    }
    //For Loop

   //Defining each variable of the input file as char for fin.getline
   char header[80], header2[80], footer [80];
   char customer_Name[50], customer_Number[50], customer_Address[50];
   char bookNumber1[50],bookTitle1[50],bookAuthor1[50],aisleNumber1[50],
   price1[50];
   char bookNumber2[50],bookTitle2[50],bookAuthor2[50],aisleNumber2[50],
   price2[50];
   char bookNumber3[50],bookTitle3[50],bookAuthor3[50],aisleNumber3[50],
   price3[50];

   float f_price1, f_price2, f_price3;
   float discount1;
   float discount2;
   float discount3;
   float pre_total, post_total, total_discount;
   float salesTax, total_amount;

    //Opening Input file and extracting all lines
    ifstream fin;
    ofstream fout;
    fin.open("Project2_4836397_Input.txt");

    //Get line command
    fin.getline(header,80);
    fin.getline(header2,80);
    fin.getline(customer_Name,50);
    fin.getline(customer_Number,50);
    fin.getline(customer_Address,50);
    fin.getline(bookNumber1,50);
    fin.getline(bookTitle1,50);
    fin.getline(bookAuthor1,50);
     fin.getline(aisleNumber1,50);
      fin.getline(price1,50);
       fin.getline(bookNumber2,50);
    fin.getline(bookTitle2,50);
    fin.getline(bookAuthor2,50);
     fin.getline(aisleNumber2,50);
      fin.getline(price2,50);
      fin.getline(bookNumber3,50);
    fin.getline(bookTitle3,50);
    fin.getline(bookAuthor3,50);
     fin.getline(aisleNumber3,50);
      fin.getline(price3,50);
     fin.getline(footer,80);

//convert from char to float
       //float f_price1, f_price2, f_price3;
      f_price1= atof (price1);
      f_price2= atof (price2);
      f_price3= atof (price3);


cout << setprecision(2) << fixed << showpoint << left;

//If book 1 price is over $90, give 5% discount

if (f_price1 >= 90)
{
    //float discount1;
    discount1 = (f_price1*0.05);

    cout<< "Your discount on book 1 is " << discount1 <<endl;
}
else if (f_price1 < 90)
{
    discount1 = 0;
}

 //If book 2 price is over $90, give 5% discount
if (f_price2 >= 90)
{
    //float discount2;
    discount2 = (f_price2*0.05);

    cout<< "Your discount on book 2 is " << discount2 <<endl;
}
else if (f_price2 < 90)
{
    discount2 = 0;
}


//If book 3 price is over $90, give 5% discount
if (f_price3 >= 90)
{
    //float discount3;
    discount3= (f_price3*0.05);
    cout<< "Your discount on Book 3 is " << discount3 <<endl;
}
else if (f_price3 < 90)
{
    discount3 = 0;
}

//Calculate total before tax and discounts / after tax and discounts
//float pre_total, post_total, total_discount;
pre_total=(f_price1+f_price2+f_price3);
total_discount=(discount1+discount2+discount3);
post_total=(pre_total-total_discount);

//Calculate Sales Tax
//float salesTax;
salesTax=((post_total)*0.08);
total_amount= (post_total+salesTax);

//Creating and extracting Output File
    ofstream fout;
    fout.open("Project2_4836397_Output.txt");
    fout<< "\t \t " << header <<endl;
    fout << "\t \t \t" << header2 <<endl;

    //Formating Output and stream manipulation
    //Header and Customer Info
    fout << setprecision(2) << fixed << showpoint << left;
    fout<< "Customer Name: " <<customer_Name<< endl;
    fout << "Customer Telephone Number: " <<customer_Number<<endl;
    fout << "Customer Address: " <<customer_Address<<endl;
    fout << " " <<endl;

    //Book 1
    fout << setw(18) << "Book Number: " <<setw(20) << bookNumber1 <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << bookTitle1 <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << bookAuthor1 <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << aisleNumber1 <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << f_price1 <<endl;
    fout << setw(18) << "Cost Discount: " <<setw (20) << discount1 <<endl;
    fout << " " <<endl;

    //Book 2
    fout << setw(18) << "Book Number: " <<setw(20) << bookNumber2 <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << bookTitle2 <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << bookAuthor2 <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << aisleNumber2 <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << f_price2 <<endl;
    fout << setw(18) << "Cost Discount: " <<setw (20) << discount2 <<endl;
    fout << " " <<endl;

    //Book 3
    fout << setw(18) << "Book Number: " <<setw(20) << bookNumber3 <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << bookTitle3 <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << bookAuthor3 <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << aisleNumber3 <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << f_price3 <<endl;
    fout << setw(18) << "Cost Discount: " <<setw (20) << discount3 <<endl;
    fout << " " <<endl;

    //Sub Total, Discount, and Final Total
    fout <<setw(30)<< "Sub Total of Three Books: " <<setw(10)<< pre_total <<endl;
    fout <<setw(30)<< "Total Discount: " << total_discount <<setw(10)<<endl;
    fout <<setw(30)<< "Subtotal after Discount: " << post_total <<setw(10)<<endl;
    fout << " " <<endl;

    //Sales Tax
    fout << setw(30) << "Sales Tax Amount: " << salesTax << endl;
    fout << " " <<endl;

    //Total Amount due
    fout<< setw(30) << "Total Amount Paid: " << total_amount <<endl;
    fout << " " <<endl;

    //Footer
    fout << "\t \t" <<footer<<endl;

//Close Files
fout.close();
fin.close();
    return 0;
}

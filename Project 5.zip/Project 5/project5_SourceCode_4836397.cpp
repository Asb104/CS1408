/* Andrew Baker
CS Project Number 5
University Bookstore Receipt Output File Program
Last Date Modified: 11/14/2017 at 5:08pm */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <cstdlib>
#include <string>
using namespace std;
void inputData(int [5][2], double [5][3][2], string [5][5], string [5][3][4]); // It will read numeric and non-numeric data from the input file called
//Project5_studentID_Input.txt into proper arrays, call ValidateData to validate.
void validateData(string [5][5], string[5][3][4]); //: These will be overloaded functions with same name.
//One function will validate non-numeric data and the other will validate numeric data.
void validateData(double [5][3][2], int [5][2]);
void computeDiscount(double [5][3][2]); //: This function will be called for each book in the book loop and it will compute cost discount of the book.
void computeTotals(double [5][5], double [5][3][2]); // This function will be called for each customer in the customer
//loop and it will compute Subtotal after Discount, Sales Tax Amount, and the Total Amount Paid.
void outputData(double [5][5], double [5][3][2],
                int [5][2], string [5][5], string [5][3][4]);//It will write all receipts to the file called OutputData.
//Since you are keeping all data in arrays which remain in the memory all the time till the end of the execution of your program,
 //this function can be called in the customer loop and provided all the information to write the receipt into the file.
string c;
   int CUSTOMER=5;
const int BOOKS = 3;
const int TWO =2;
const int FOUR =4;
    double Discoint [3];
    string customers_NonNumeric[5][5];  //to store receipt title, customer name and address.
    int customers_Numeric1[5][2];    //to store customer age and number of books customer is buying.
    double customers_Numeric2[5][5];  //to store two subtotals, amounts of discounts and tax, and total amount paid.
    string books_NonNumeric[5][3][4];    //to store book numbers, titles, authors and Aisle numbers for all three books of five customers.
    double books_Numeric [5][3][2];  //to store prices and cost discounts for all three books of five customers


int main()
{
    string c;
 int CUSTOMER;
const int BOOKS = 3;
const int TWO =2;
const int FOUR =4;
    double Discoint [3];
    cout << "Please enter the number of customers that are being checked out (5 customers)." <<endl;
   cin>> CUSTOMER;
    // While confirmation loop
    while (CUSTOMER !=5)
    {
         cout << "Please enter the number of customers that are being checked out.  Please enter 5 customers." <<endl;
        cin>> CUSTOMER;
    }

inputData(customers_Numeric1, books_Numeric,
               customers_NonNumeric,books_NonNumeric);

computeDiscount(books_Numeric);

computeTotals(customers_Numeric2, books_Numeric);

outputData(customers_Numeric2, books_Numeric,
                 customers_Numeric1, customers_NonNumeric, books_NonNumeric);
return 0;
}

void inputData(int customers_Numeric1[5][2], double books_Numeric[5][3][2],
               string customers_NonNumeric[5][5],string books_NonNumeric[5][3][4])
{
    //Input output operator
    ifstream fin;
    fin.open("Project5_4836397_Input.txt");
    ofstream fout;
    fout.open("Project5_4836397_Output.txt");
    if (!fin)
    {
        return;
    }
    // for loops for file input extraction

for (int a=0; a<CUSTOMER; a++)
{
getline (fin, customers_NonNumeric[a][0]);
        getline (fin, customers_NonNumeric[a][1]);
        getline (fin, customers_NonNumeric[a][2]);
        getline (fin, customers_NonNumeric[a][3]);
        fin >> customers_Numeric1[a][0];
        fin >> customers_Numeric1[a][1];

        // three books
            for(int i = 0 ; i < BOOKS ; i++)
            {
                fin >> books_NonNumeric[a][i][0];
                fin.ignore();
                getline (fin, books_NonNumeric[a][i][1]);
                getline (fin, books_NonNumeric[a][i][2]);
                fin >> books_NonNumeric[a][i][3];
            }

                for (int x=0; x<BOOKS; x++)
                {
                     fin >> books_Numeric[a][x][0];

                }
        //fin.ignore();
        getline (fin, c);
        getline (fin, customers_NonNumeric[a][4]);
}
validateData(customers_NonNumeric, books_NonNumeric);
validateData(books_Numeric, customers_Numeric1);

}


void validateData(string customers_NonNumeric[5][5], string books_NonNumeric[5][3][4])
 {
    cout << setprecision(2) << fixed << showpoint << left;
 //If statement Confirmation of String
    for (int A=0; A<CUSTOMER; A++)
    {
        for (int B=0; B<CUSTOMER; B++)
            {
                        int Z;
                        Z=customers_NonNumeric[A][B].length();
                        if (Z>1 && Z<50)
                    {
                    cout<< "Your string is with in the Range."<<endl;
                }
                    else
                {
                    cout << "Your strings are out of range.\n";
                    return ;
                }
            }
            for (int E=0; E<BOOKS; E++)
            {
            for (int C=0; C<4; C++)
            {
            int Y;
            Y= books_NonNumeric[A][E][C].length();
            if (Y>1 && Y<50)
    {
        cout<< "Your string is with in the Range."<<endl;
    }
    else
    {
        cout << "Your strings are out of range.\n";
        return ;
    }
            }
            }
    }
return ;
}


void validateData(double books_Numeric[5][3][2],int customers_Numeric1[5][2])
{
     for (int A=0; A<CUSTOMER; A++)
     {

    for (int D=0; D<3; D++)
        {
        if (books_Numeric[A][D][0]>1.00 && books_Numeric[A][D][0]<200.00)
     {
        cout<< "Your float is with in the Range."<<endl;
    }
     else
    {
        cout << "Your floats are out of range.\n";
        return ;
}
        }
     for (int F=0; F<2; F++)
        {

        if (customers_Numeric1[A][F]>1 && customers_Numeric1[A][F]<100)
    {
        cout << "Your int is in Range \n";
    }
    else
    {
        cout << "Your int is out of Range \n";
    }
        }
     }
     return;

     }
void computeDiscount(double books_Numeric[5][3][2])
{
    for (int A=0; A<CUSTOMER; A++)
    {
        for ( int G=0; G<BOOKS; G++)
            {
            if (books_Numeric[A][G][0] > 90)
            {

                cout << "Apply Discount \n";
                books_Numeric[A][G][1]=(books_Numeric[A][G][0]*(.05));
            }
        else
           {
            cout <<"No Discount \n";
            books_Numeric[A][G][1]=0;
            }
}
    }
 return;

    }



void computeTotals(double customers_Numeric2[5][5],double books_Numeric [5][3][2])
{
 for (int j=0; j<5;j++)
    {
    for (int N=0; N<CUSTOMER; N++)
        {
            customers_Numeric2[N][0]=(books_Numeric[N][2][0]+books_Numeric[N][1][0]+books_Numeric[N][0][0]);
            customers_Numeric2[N][1]=books_Numeric[N][0][1]+books_Numeric[N][1][1]+books_Numeric[N][2][1];
            customers_Numeric2[N][2]=customers_Numeric2[N][0]-customers_Numeric2[N][1];
            customers_Numeric2[N][3]=((books_Numeric[N][2][0]+books_Numeric[N][1][1]+books_Numeric[N][0][1])*(.08));
            customers_Numeric2[N][4]=customers_Numeric2[N][2]+customers_Numeric2[N][3];
        }



        }
    return;
    }


void outputData(double customers_Numeric2[5][5],double books_Numeric [5][3][2],
                int customers_Numeric1[5][2],string customers_NonNumeric[5][5], string books_NonNumeric[5][3][4])
{
ofstream fout;
    fout.open("Project5_4836397_Output.txt");
    ifstream fin;
    fin.open("Project5_4836397_Input.txt");
for (int j=0; j<5;j++)
    {

        //Creating and extracting Output File
    fout<< "\t \t " << customers_NonNumeric[j][0] <<endl;
    fout << "\t \t \t" << customers_NonNumeric[j][1] <<endl;
    //Formating Output and stream manipulation
    //Header and Customer Info
    fout << setprecision(2) << fixed << showpoint << left;
    fout<< "Customer Name: " <<customers_NonNumeric[j][2]<< endl;
    fout << "Customer Address: " << customers_NonNumeric[j][3]<<endl;
        fout << "Customer Age: " <<  customers_Numeric1[j][0] <<endl;
        fout << "Number of Books Purchased: "<< customers_Numeric1[j][1] <<endl;
        fout << " " <<endl;
        //Book 1
    fout << setw(18) << "Book Number: " <<setw(20) << books_NonNumeric[j][0][0] <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << books_NonNumeric[j][0][1] <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << books_NonNumeric[j][0][2] <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << books_NonNumeric[j][0][3] <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << books_Numeric[j][0][0] <<endl;
   fout << setw(18) << "Cost Discount: " <<setw (20) << books_Numeric[j][0][1] <<endl;
    fout << " " <<endl;
    //Book 2
     fout << setw(18) << "Book Number: " <<setw(20) << books_NonNumeric[j][1][0] <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << books_NonNumeric[j][1][1] <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << books_NonNumeric[j][1][2] <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << books_NonNumeric[j][1][3] <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << books_Numeric[j][1][0] <<endl;
    fout << setw(18) << "Cost Discount: " <<setw (20) << books_Numeric[j][1][1] <<endl;
    fout << " " <<endl;

     fout << setw(18) << "Book Number: " <<setw(20) << books_NonNumeric[j][2][0] <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << books_NonNumeric[j][2][1] <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << books_NonNumeric[j][2][2] <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << books_NonNumeric[j][2][3] <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << books_Numeric[j][2][0] <<endl;
    fout << setw(18) << "Cost Discount: " <<setw (20) << books_Numeric[j][2][1]<<endl;

fout << " " <<endl;
    fout << " " <<endl;

     //Sub Total, Discount, and Final Total
    fout <<setw(30)<< "Sub Total of Books: " <<setw(10)<< customers_Numeric2[j][0] <<endl;
    fout <<setw(30)<< "Total Discount: " << customers_Numeric2[j][1] <<setw(10)<<endl;
    fout <<setw(30)<< "Subtotal after Discount: " << customers_Numeric2[j][2] <<setw(10)<<endl;
    fout << " " <<endl;
    //Sales Tax
    fout << setw(30) << "Sales Tax Amount: " << customers_Numeric2[j][3] << endl;
    fout << " " <<endl;
    //Total Amount due
    fout<< setw(30) << "Total Amount Paid: " << customers_Numeric2[j][4] <<endl;

 fout << "\t \t" <<endl;

     fout << " " <<endl;
    fout << customers_NonNumeric[j][4];
    fout << " " <<endl;
    fout << " " <<endl;
    }
//Footer
//Close Files

fout.close();
fin.close();
    return ;

}

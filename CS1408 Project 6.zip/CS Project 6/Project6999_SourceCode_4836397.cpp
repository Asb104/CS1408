 //University Bookstore Receipt Output File Program
#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <cstdlib>
#include <string>
using namespace std;
string c;
const int Three=3;
struct bookInfo
{
    string bookCode;
    string titles;
    string authors;
    int aisleNumbers;
    double price;
    double discount;
};
struct personInfo
{
    string Title1;
    string Title2;
    string name;
    string address;
    int age;
    int purchaseNum;
    string footer;
};
struct Customer
{
    personInfo Info;
    bookInfo book[3];
    double tax;
    double bookTotal;
    double discountTotal;
    double subtotal;
    double finalTotal;
};
const int SIZE =5;
    void inputData(Customer[5], int);
void validateData(Customer[5], int);
void validateData2(Customer[5], int);
void computeDiscount(Customer[5], int); //: This function will be called for each book in the book loop and it will compute cost discount of the book.
void computeTotals(Customer [5], int); // This function will be called for each customer in the customer
//loop and it will compute Subtotal after Discount, Sales Tax Amount, and the Total Amount Paid.
void outputData(Customer[5], int);//It will write all receipts to the file called OutputData.
//Since you are keeping all data in arrays which remain in the memory all the time till the end of the execution of your program,
//this function can be called in the customer loop and provided all the information to write the receipt into the file
int main()
    {
        string c;
        int SIZE;
        cout << "Please enter the number of customers that are being checked out (5 customers)." <<endl;
        cin>> SIZE;
        // While confirmation loop
        while (SIZE !=5)
        {
            cout << "Please enter the number of customers that are being checked out.  Please enter 5 customers." <<endl;
            cin>> SIZE;
        }
        Customer Bobby[SIZE];
        inputData(Bobby, SIZE);
        computeDiscount(Bobby, SIZE);
        computeTotals(Bobby, SIZE);

        outputData(Bobby, SIZE);
        return 0;
}
void inputData(Customer Bobby[SIZE], int SIZE)
{
    //Input output operator
    ifstream fin;
    fin.open("_Input.txt");
    ofstream fout;
    fout.open("_Output.txt");
    if (!fin)
    {
        return;
    }
    // for loops for file input extraction
    for (int a=0; a<SIZE; a++)
    {
        getline (fin, Bobby[a].Info.Title1);
        getline (fin, Bobby[a].Info.Title1);
        getline (fin, Bobby[a].Info.name);
        getline (fin, Bobby[a].Info.address);
        fin >> Bobby[a].Info.name;
        fin >> Bobby[a].Info.purchaseNum;
        // three books
        for(int i = 0 ; i < Three ; i++)
        {
            fin >> Bobby[a].book[i].bookCode;
            fin.ignore();
            getline (fin, Bobby[a].book[i].titles);
            getline (fin, Bobby[a].book[i].authors);
            fin >> Bobby[a].book[i].aisleNumbers;
        }
        for (int x=0; x<Three; x++)
        {
            fin >> Bobby[a].book[x].price;
        }
        //fin.ignore();
        getline (fin, c);
        getline (fin, Bobby[a].Info.footer);
    }
    validateData(Bobby, SIZE);
    validateData2(Bobby, SIZE);
}
void validateData(Customer Bobby[],int SIZE)
{
    cout << setprecision(2) << fixed << showpoint << left;
    //If statement Confirmation of String
    for (int A=0; A<SIZE; A++)
    {
        for (int B=0; B<3; B++)
        {
            int Z;
            Z=Bobby[A].book[B].bookCode.length();
            if (Z>1 && Z<50)
            {
                cout<< "Your string is with in the Range."<<endl;
            }
            else
            {
                cout << "Your strings are out of range.\n";
                return ;
            }
        }
            for (int C=0; C<3; C++)
            {
                int Y;
                Y= Bobby[A].book[C].titles.length();
                if (Y>1 && Y<50)
                {
                    cout<< "Your string is with in the Range."<<endl;
                }
                else
                {
                    cout << "Your strings are out of range.\n";
                    return ;
                }
            }
    }
    //return ;
}
void validateData2(Customer Bobby[], int SIZE)
{
    for (int A=0; A<SIZE; A++)
    {
        for (int D=0; D<Three; D++)
        {
            if (Bobby[A].book[D].price>1.00 && Bobby[A].book[D].price<200.00)
            {
                cout<< "Your float is with in the Range."<<endl;
            }
            else
            {
                cout << "Your floats are out of range.\n";
                return ;
            }
        }
        for (int F=0; F<Three; F++)
        {
            if (Bobby[A].book[F].aisleNumbers>1 && Bobby[A].book[F].aisleNumbers<100)
            {
                cout << "Your int is in Range \n";
            }
            else
            {
                cout << "Your int is out of Range \n";
            }
        }
    }
    return;
}
void computeDiscount(Customer Bobby[], int SIZE)
{
    for (int A=0; A<SIZE; A++)
    {
        for ( int G=0; G<Three; G++)
        {
            if (Bobby[A].book[G].price > 90)
            {
                cout << "Apply Discount \n";
                Bobby[A].book[G].discount= Bobby[A].book[G].price*(.05);
            }
            else
            {
                cout <<"No Discount \n";
            Bobby[A].book[G].discount=0;
            }
        }
    }
    return;
}
void computeTotals(Customer Bobby[], int SIZE)
{
    for (int j=0; j<SIZE;j++)
    {
        for (int N=0; N<Three; N++)
        {
            Bobby[j].bookTotal=+Bobby[j].book[N].price;
            Bobby[j].discountTotal=+Bobby[j].book[N].discount;
            Bobby[j].subtotal=(Bobby[j].bookTotal)-(Bobby[j].discountTotal);
            Bobby[j].tax=(Bobby[j].bookTotal)*(0.08);
            Bobby[j].finalTotal=(Bobby[j].bookTotal)+(Bobby[j].tax);
        }
    }
    return;
}
void outputData(Customer Bobby[], int SIZE)
{
    ofstream fout;
    fout.open("_Output.txt");
    ifstream fin;
    fin.open("_Input.txt");
    for (int j=0; j<5;j++)
    {

        //Creating and extracting Output File
        fout<< "\t \t " << Bobby[j].Info.Title1 <<endl;
        fout << "\t \t \t" << Bobby[j].Info.Title2<<endl;
        //Formating Output and stream manipulation
        //Header and Customer Info
        fout << setprecision(2) << fixed << showpoint << left;
        fout<< "Customer Name- " <<Bobby[j].Info.name<< endl;
        fout << "Customer Address- " << Bobby[j].Info.address<<endl;
        fout << "Customer Age- " << Bobby[j].Info.age <<endl;
        fout << "Number of Books Purchased- "<< Bobby[j].Info.purchaseNum <<endl;
        fout << " " <<endl;
        for(int i=0; i<Three; i++)
        {
        //Book 1
        fout << setw(18) << "Book Number- " <<setw(20) << Bobby[j].book[i].bookCode <<endl;
        fout << setw(18) << "Book Title- " <<setw(20) << Bobby[j].book[i].titles <<endl;
        fout << setw(18) << "Book Author- " <<setw(20) << Bobby[j].book[i].authors <<endl;
        fout << setw(18) << "Aisle Number- " <<setw(20) << Bobby[j].book[i].aisleNumbers <<endl;
        fout << setw(18) << "Price of the Book- " <<setw(20) << Bobby[j].book[i].price <<endl;
        fout << setw(18) << "Cost Discount- " <<setw (20) << Bobby[j].book[i].discount <<endl;
        fout << " " <<endl;
        }
        fout << " " <<endl;
        fout << " " <<endl;
        //Sub Total, Discount, and Final Total
        fout <<setw(30)<< "Sub Total of Books- " <<setw(10)<< Bobby[j].bookTotal <<endl;
        fout <<setw(30)<< "Total Discount- " << Bobby[j].discountTotal <<setw(10)<<endl;
        fout <<setw(30)<< "Subtotal after Discount- " << Bobby[j].subtotal <<setw(10)<<endl;
        fout << " " <<endl;
        //Sales Tax
        fout << setw(30) << "Sales Tax Amount- " << Bobby[j].tax << endl;
        fout << " " <<endl;
        //Total Amount due
        fout<< setw(30) << "Total Amount Paid- " << Bobby[j].finalTotal <<endl;
        fout << "\t \t" <<endl;
        fout << " " <<endl;
        fout << Bobby[j].Info.footer<<endl;
        fout << " " <<endl;
        fout << " " <<endl;
    }
    //Footer
    //Close Files
    fout.close();
    fin.close();
    return ;



}

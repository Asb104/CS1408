/* Andrew Baker
CS Project Number 2
University Bookstore Receipt Output File Program
Last Date Modified: 11/1/2017 at 1:08pm */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <cstdlib>
#include <string>
using namespace std;
int main()
{
   //Defining each variable of the input file as char for fin.getline
  /* char header[80], header2[80], footer [80];
   char customer_Name[50], customer_Number[50], customer_Address[50];
   char bookNumber1[50],bookTitle1[50],bookAuthor1[50],aisleNumber1[50],
   price1[50];
   char bookNumber2[50],bookTitle2[50],bookAuthor2[50],aisleNumber2[50],
   price2[50];
   char bookNumber3[50],bookTitle3[50],bookAuthor3[50],aisleNumber3[50],
   price3[50];
    char bookNumber4[50],bookTitle4[50],bookAuthor4[50],aisleNumber4[50],
   price4[50];
*/
string c;
 int CUSTOMER;
const int BOOKS = 3;
const int TWO =2;
const int FOUR =4;
    double Discoint [3];
    /* float f_price1, f_price2, f_price3, f_price4;
   float discount1;
   float discount2;
   float discount3, discount4;
   float pre_total, post_total, total_discount;
   float salesTax, total_amount;
    string Author, Title, Number;
   int i_Aisle;
 int Size, i_Aisle1;
   */
   cout << "Please enter the number of customers that are being checked out (5 customers)." <<endl;
   cin>> CUSTOMER;
    // While confirmation loop
    while (CUSTOMER !=5)
    {
         cout << "Please enter the number of customers that are being checked out.  Please enter 5 customers." <<endl;
        cin>> CUSTOMER;
    }
   //Assign Arrays
      string customers_NonNumeric[CUSTOMER][CUSTOMER];  //to store receipt title, customer name and address.
    int customers_Numeric1[CUSTOMER][TWO];    //to store customer age and number of books customer is buying.
    double customers_Numeric2[CUSTOMER][CUSTOMER];  //to store two subtotals, amounts of discounts and tax, and total amount paid.
    string books_NonNumeric[CUSTOMER][BOOKS][FOUR];    //to store book numbers, titles, authors and Aisle numbers for all three books of five customers.
    double books_Numeric [CUSTOMER][BOOKS][TWO];  //to store prices and cost discounts for all three books of five customers

   //Input output operator
    ifstream fin;
    fin.open("Project4_4836397_Input.txt");
    ofstream fout;
    fout.open("Project4_4836397_Output.txt");
    // for loops for file input extraction
for (int a=0; a<CUSTOMER; a++)
{

        getline (fin, customers_NonNumeric[a][0]);
        getline (fin, customers_NonNumeric[a][1]);
        getline (fin, customers_NonNumeric[a][2]);
        getline (fin, customers_NonNumeric[a][3]);
        fin >> customers_Numeric1[a][0];
        fin >> customers_Numeric1[a][1];

        // three books
            for(int i = 0 ; i < BOOKS ; i++)
            {
                fin >> books_NonNumeric[a][i][0];
                fin.ignore();
                getline (fin, books_NonNumeric[a][i][1]);
                getline (fin, books_NonNumeric[a][i][2]);
                fin >> books_NonNumeric[a][i][3];
            }

                for (int x=0; x<BOOKS; x++)
                {
                     fin >> books_Numeric[a][x][0];

                }
        //fin.ignore();
        getline (fin, c);
        getline (fin, customers_NonNumeric[a][4]);


}


/*
    fin.getline(header,80);
    fin.getline(header2,80);
    //For Loop
for (int x=0; x<Size; x++)
{

    //Opening Input file and extracting all lines
    //Get line command
    fin.getline(customer_Name,50);
    fin.getline(customer_Number,50);
    fin.getline(customer_Address,50);
    fin.getline(bookNumber1,50);
    fin.getline(bookTitle1,50);
    fin.getline(bookAuthor1,50);
     fin.getline(aisleNumber1,50);
      fin.getline(price1,50);
       fin.getline(bookNumber2,50);
    fin.getline(bookTitle2,50);
    fin.getline(bookAuthor2,50);
     fin.getline(aisleNumber2,50);
      fin.getline(price2,50);
      fin.getline(bookNumber3,50);
    fin.getline(bookTitle3,50);
    fin.getline(bookAuthor3,50);
     fin.getline(aisleNumber3,50);
      fin.getline(price3,50);
       fin.getline(bookNumber4,50);
    fin.getline(bookTitle4,50);
    fin.getline(bookAuthor4,50);
     fin.getline(aisleNumber4,50);
      fin.getline(price4,50);
      fin.getline(footer,80);
//convert from char to float
       //float f_price1, f_price2, f_price3;
      f_price1= atof (price1);
      f_price2= atof (price2);
      f_price3= atof (price3);
    f_price4= atof (price4);
     //Convert to int
     i_Aisle1 = atoi (aisleNumber1);
     //Strings
     Author = "Reed Colemen";
    Title = "The Hangman's Sonnet";
    Number = "AB532";
    */
cout << setprecision(2) << fixed << showpoint << left;
//If statement Confirmation of String
    for (int A=0; A<CUSTOMER; A++)
    {
        for (int B=0; B<CUSTOMER; B++)
            {
                        int Z;
                        Z=customers_NonNumeric[A][B].length();
                        if (Z>1 && Z<50)
                    {
                    cout<< "Your string is with in the Range."<<endl;
                }
                    else
                {
                    cout << "Your strings are out of range.\n";
                    return 0;
                }
            }
            for (int E=0; E<BOOKS; E++)
            {
            for (int C=0; C<4; C++)
            {
            int Y;
            Y= books_NonNumeric[A][E][C].length();
            if (Y>1 && Y<50)
    {
        cout<< "Your string is with in the Range."<<endl;
    }
    else
    {
        cout << "Your strings are out of range.\n";
        return 0;
    }
            }
            }
       /* if (c>1 && c<50)
    {
        cout<< "Your string is with in the Range."<<endl;
    }
    else
    {
        cout << "Your strings are out of range.\n";
        return 0;
    }
*/

        //If statement confirming float range
        for (int D=0; D<3; D++)
        {
        if (books_Numeric[A][D][0]>1.00 && books_Numeric[A][D][0]<200.00)
     {
        cout<< "Your float is with in the Range."<<endl;
    }
     else
    {
        cout << "Your floats are out of range.\n";
        return 0;
    }
        }
       /*
        if (f_price2>1.00 && f_price2<200.00)
    {
        cout<< "Your float is with in the Range."<<endl;
    }
    else
    {
        cout << "Your floats are out of range.\n";
        return 0;
    }
        if (f_price3>1.00 && f_price3<200.00)
    {
        cout<< "Your float is with in the Range."<<endl;
    }
    else
    {
        cout << "Your floats are out of range.\n";
        return 0;
    }
        if (f_price4>1.00 && f_price4<200.00)
    {
        cout<< "Your float is with in the Range."<<endl;
    }
    else
    {
    cout << "Your floats are out of range.\n";
        return 0;
    }
       */
        //Confirming int range
      for (int F=0; F<2; F++)
        {

        if (customers_Numeric1[A][F]>1 && customers_Numeric1[A][F]<100)
    {
        cout << "Your int is in Range \n";
    }
    else
    {
        cout << "Your int is out of Range \n";
    }
        }
        //If book price is over $90, give 5% discount
for ( int G=0; G<BOOKS; G++)
{
    if (books_Numeric[A][G][0] > 90)
        {

            cout << "Apply Discount \n";
            books_Numeric[A][G][1]=(books_Numeric[A][G][0]*(.08));
        }
    else
        cout <<"No Discount \n";
}

    }
//Calculate total before tax and discounts / after tax and discounts
//float pre_total, post_total, total_discount;



    for (int j=0; j<5;j++)
    {

        //Creating and extracting Output File
    fout<< "\t \t " << customers_NonNumeric[j][0] <<endl;
    fout << "\t \t \t" << customers_NonNumeric[j][1] <<endl;
    //Formating Output and stream manipulation
    //Header and Customer Info
    fout << setprecision(2) << fixed << showpoint << left;
    fout<< "Customer Name: " <<customers_NonNumeric[j][2]<< endl;
    fout << "Customer Address: " << customers_NonNumeric[j][3]<<endl;
        fout << "Customer Age: " <<  customers_Numeric1[j][0] <<endl;
        fout << "Number of Books Purchased: "<< customers_Numeric1[j][1] <<endl;
        fout << " " <<endl;
        //Book 1
    fout << setw(18) << "Book Number: " <<setw(20) << books_NonNumeric[j][0][0] <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << books_NonNumeric[j][0][1] <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << books_NonNumeric[j][0][2] <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << books_NonNumeric[j][0][3] <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << books_Numeric[j][0][0] <<endl;
   fout << setw(18) << "Cost Discount: " <<setw (20) << books_Numeric[j][0][1] <<endl;
    fout << " " <<endl;
    //Book 2
     fout << setw(18) << "Book Number: " <<setw(20) << books_NonNumeric[j][1][0] <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << books_NonNumeric[j][1][1] <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << books_NonNumeric[j][1][2] <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << books_NonNumeric[j][1][3] <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << books_Numeric[j][1][0] <<endl;
    fout << setw(18) << "Cost Discount: " <<setw (20) << books_Numeric[j][1][1] <<endl;
    fout << " " <<endl;

     fout << setw(18) << "Book Number: " <<setw(20) << books_NonNumeric[j][2][0] <<endl;
    fout << setw(18) << "Book Title: " <<setw(20) << books_NonNumeric[j][2][1] <<endl;
    fout << setw(18) << "Book Author: " <<setw(20) << books_NonNumeric[j][2][2] <<endl;
    fout << setw(18) << "Aisle Number: " <<setw(20) << books_NonNumeric[j][2][3] <<endl;
    fout << setw(18) << "Price of the Book: " <<setw(20) << books_Numeric[j][2][0] <<endl;
    fout << setw(18) << "Cost Discount: " <<setw (20) << books_Numeric[j][2][1]<<endl;

fout << " " <<endl;
    fout << " " <<endl;
        for (int N=0; N<CUSTOMER; N++)
        {
            customers_Numeric2[N][0]=(books_Numeric[N][2][0]+books_Numeric[N][1][0]+books_Numeric[N][0][0]);
            customers_Numeric2[N][1]=books_Numeric[N][0][1]+books_Numeric[N][1][1]+books_Numeric[N][2][1];
            customers_Numeric2[N][2]=customers_Numeric2[N][0]-customers_Numeric2[N][1];
            customers_Numeric2[N][3]=((books_Numeric[N][2][0]+books_Numeric[N][1][1]+books_Numeric[N][0][1])*(.08));
            customers_Numeric2[N][4]=customers_Numeric2[N][2]+customers_Numeric2[N][3];
        }
    //Sub Total, Discount, and Final Total
    fout <<setw(30)<< "Sub Total of Books: " <<setw(10)<< customers_Numeric2[j][0] <<endl;
    fout <<setw(30)<< "Total Discount: " << customers_Numeric2[j][1] <<setw(10)<<endl;
    fout <<setw(30)<< "Subtotal after Discount: " << customers_Numeric2[j][2] <<setw(10)<<endl;
    fout << " " <<endl;
    //Sales Tax
    fout << setw(30) << "Sales Tax Amount: " << customers_Numeric2[j][3] << endl;
    fout << " " <<endl;
    //Total Amount due
    fout<< setw(30) << "Total Amount Paid: " << customers_Numeric2[j][4] <<endl;

 fout << "\t \t" <<endl;

     fout << " " <<endl;
    fout << customers_NonNumeric[j][4];
    fout << " " <<endl;
    fout << " " <<endl;
    }
//Footer
//Close Files

fout.close();
fin.close();
    return 0;
}


